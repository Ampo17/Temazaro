import React, { useEffect, useState } from 'react';
import logo from './logo.svg';
import './App.css';
import axios from 'axios';
import {Adatok} from './Adatok';
import apiClient from './apiClient';

function App() {
  const [data,setData] = useState(Array<Adatok>)

  useEffect(()=>{
    apiClient
  .get('/api/users')
  .then(response => {
    setData(response.data);
  })
  .catch((error) => {
    alert(error);
  });
  }, [data]);

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.tsx</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
        <table>
        <th>Email</th>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Class</th>
        {data.map((sz)=>
        <tr>
          <td><p>{sz.email}</p></td>
          <td><p>{sz.firstName}</p></td>
          <td><p>{sz.lastName}</p></td>
          <td><p>{sz.id}</p></td>
        </tr>)}
        </table>
      </header>
    </div>
  );
}

export default App;
