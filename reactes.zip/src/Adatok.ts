export type Adatok={
    email:String;
    firstName: String;
    lastName: String;
    id: String;
};
export default Adatok;