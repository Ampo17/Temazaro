import React, { useState } from 'react';

const Hiba = () =>{
    return(
        <h1>
            404 Az oldal nem található
        </h1>
    )
}

export default Hiba;